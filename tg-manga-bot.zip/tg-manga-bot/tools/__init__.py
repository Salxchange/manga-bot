from .singleton import LanguageSingleton
